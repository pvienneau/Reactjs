import React from 'react';

export default function(props) {
  return (
    <h1>Homepage</h1>
  );
}
