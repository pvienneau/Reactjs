import React from 'react';

export default function(props) {
  return (
    <h1>Page 1</h1>
  );
}
