import React from 'react';

const Home = React.createClass({
  render: function() {
    return (
      <h1>Hello World</h1>
    );
  }
});

export default Home
