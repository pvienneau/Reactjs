import React from 'react';

export default function(props) {
  return (
    <h1>Page 2</h1>
  );
}
